#ifndef OPERANDOS_H
#define OPERANDOS_H
#include "MV.h"

int getOperando(MV *mv, char op, int ipAct, int iptemp);
void setOperando(MV *mv, char op, int valor, int ipAct, int);
#endif
